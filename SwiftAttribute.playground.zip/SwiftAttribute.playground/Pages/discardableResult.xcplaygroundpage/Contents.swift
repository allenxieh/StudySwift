//: [Previous](@previous)
//: ![图片](discardableResult.png)
//: [Next](@next)

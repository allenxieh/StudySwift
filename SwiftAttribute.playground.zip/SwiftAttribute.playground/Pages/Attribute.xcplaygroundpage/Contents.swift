/*:
 # Attributes
 - - -
 The Swift Programming Language:
  [Attributes](https://docs.swift.org/swift-book/ReferenceManual/Attributes.html)
 * [@main](main)
 * [@available](available)
 * [@discardableResult](discardableResult)
 * [@dynamicMemberLookup](dynamicMemberLookup)
 * [@dynamicCallable](dynamicCallable)
 * [@objc](objc)
 * [@propertyWrapper](propertyWrapper)
 * [@resultBuilder](resultBuilder)
 */
